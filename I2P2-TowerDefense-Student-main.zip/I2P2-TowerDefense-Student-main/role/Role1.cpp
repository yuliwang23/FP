//
// Created by IRIS0817 on 2024/6/12.
//
#include <string>
#include "Role1.hpp"
//Role1
Role1::Role1(int x, int y) : Role("our_game/role.png", x, y, 10, 50, 30, 30) {}



