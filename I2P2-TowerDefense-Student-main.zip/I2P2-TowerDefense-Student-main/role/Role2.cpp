//
// Created by IRIS0817 on 2024/6/12.

#include <string>
#include "Role2.hpp"
//Role2
Role2::Role2(int x, int y) : Role("our_game/role2.png", x, y, 10, 50, 30, 30) {}

