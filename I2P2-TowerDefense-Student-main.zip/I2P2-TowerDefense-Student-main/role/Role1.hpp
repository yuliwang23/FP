//
// Created by IRIS0817 on 2024/6/12.
//

#ifndef INC_2024_I2P2_TOWERDEFENSE_WITH_ANSWER_ROLE1_HPP
#define INC_2024_I2P2_TOWERDEFENSE_WITH_ANSWER_ROLE1_HPP
#include "Role.hpp"

class Role1 : public Role {
public:
    Role1(int x, int y);
};

#endif //INC_2024_I2P2_TOWERDEFENSE_WITH_ANSWER_ROLE1_HPP
