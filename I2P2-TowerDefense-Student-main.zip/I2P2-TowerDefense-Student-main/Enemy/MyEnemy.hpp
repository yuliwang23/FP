#ifndef MYENEMY_HPP
#define MYENEMY_HPP
#include "Enemy.hpp"

class MyEnemy : public Enemy {
public:
	MyEnemy(int x, int y);
};
#endif // MYENEMY_HPP