#ifndef SICKLEPLANT_HPP
#define SICKLEPLANT_HPP
#include "Plant.hpp"

class SicklePlant: public Plant {
public:
	static const int HarvestTime;
    SicklePlant(float x, float y);
};
#endif // VSICKLEPLANT_HPP
