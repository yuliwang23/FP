//
// Created by IRIS0817 on 2024/6/12.
//
#include <cmath>
#include <random>
#include <string>
#include <utility>
#include <iostream>

#include "UI/Animation/DirtyEffect.hpp"
#include "Engine/Group.hpp"
#include "Engine/IObject.hpp"
#include "Plant/Up.hpp"
#include "Scene/FarmScene.hpp"
#include "Engine/Point.hpp"
#include "Plant/Plant.hpp"
#include "Engine/GameEngine.hpp"

Up::Up(int x, int y) :
        Plant(0, "farm/Up.png", x, y, 0, 0, 0, 0) {
}

void Up::Update(float deltaTime) {
    std::cout<<"here\n";
    Sprite::Update(deltaTime);
    FarmScene* scene = getFarmScene();
    std::cout<<"timer:"<<timer;
    timer-=deltaTime;

    if(timer<=0){
        //
        std::cout<<"time=0\n";
        getFarmScene()->UpGroup->RemoveObject(objectIterator);
        //scene->ClearBomb(Position.x,Position.y,CollisionRadius);
    }
}



