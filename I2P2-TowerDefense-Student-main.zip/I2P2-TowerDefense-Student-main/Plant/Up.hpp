//
// Created by IRIS0817 on 2024/6/12.
//

#ifndef INC_2024_I2P2_TOWERDEFENSE_WITH_ANSWER_BOMB1_HPP
#define INC_2024_I2P2_TOWERDEFENSE_WITH_ANSWER_BOMB1_HPP
#include <allegro5/base.h>
#include <list>

#include "Plant/Plant.hpp"
#include "Scene/FarmScene.hpp"
//class FramScene;
namespace Engine {
    struct Point;
}  // namespace Engine

class Up : public Plant{
protected:
    //const float rotateRadian = 2 * ALLEGRO_PI;
    //std::list<Bullet*>::iterator lockedBulletIterator;
    //FarmScene* getFarmScene();
public:
    float timer=1;
    explicit Up(int x,int y);
    virtual void Update(float deltaTime) override;
};

#endif //INC_2024_I2P2_TOWERDEFENSE_WITH_ANSWER_BOMB1_HPP
